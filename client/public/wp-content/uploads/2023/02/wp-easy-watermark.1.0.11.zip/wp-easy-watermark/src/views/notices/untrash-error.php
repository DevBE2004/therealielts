<?php
/**
 * Untrash error message
 *
 * @package easy-watermark
 */

?>
<div class="notice notice-error is-dismissible">
		<p><?php esc_html_e( 'You can only have 2 active watermarks. Please delete some other watermark to restore this one.', 'easy-watermark' ); ?></p>
</div>
