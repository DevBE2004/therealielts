<?php
/**
 * Watermark number exceeded error message
 *
 * @package easy-watermark
 */

?>
<div class="notice notice-error">
	<p><?php esc_html_e( 'You can only configure 2 watermarks. Please edit already existing ones.', 'easy-watermark' ); ?></p>
</div>
