<?php
/**
 * Attachment ID field
 *
 * @package easy-watermark
 */

?>

<input type="hidden" name="ew-previous-attachment-id" value="<?php echo esc_attr( $attachment_id ); ?>" />
